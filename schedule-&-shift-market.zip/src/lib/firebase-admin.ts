import adminApp from 'firebase-admin/app';
import adminAuth from 'firebase-admin/auth';
import firebaseConfig from '../../firebase-applet-config.json' with { type: 'json' };

const { initializeApp, getApps } = adminApp;
const { getAuth } = adminAuth;

if (!getApps().length) {
  initializeApp({
    projectId: firebaseConfig.projectId,
  });
}

export const adminAuthInstance = getAuth();
