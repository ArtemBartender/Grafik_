import { Request, Response, NextFunction } from 'express';
import { adminAuthInstance } from './firebase-admin.ts';
import { db } from '../db/index.ts';
import { users } from '../db/schema.ts';
import { eq } from 'drizzle-orm';

export interface AuthRequest extends Request {
  user?: any; // The database user object
  firebaseUser?: any; // The decoded Firebase ID Token payload
}

export const authGuard = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Auth token expired or invalid (missing)' });
  }

  const token = authHeader.split('Bearer ')[1];
  try {
    let decodedToken: any = null;
    let isLegacy = false;

    // Check if it's a legacy base64 token (doesn't start with "ey" which is standard for Firebase JWTs)
    if (!token.startsWith('ey')) {
      isLegacy = true;
    }

    if (isLegacy) {
      try {
        const payloadStr = Buffer.from(token, 'base64').toString('utf-8');
        const payload = JSON.parse(payloadStr);
        decodedToken = { 
          uid: null, 
          email: payload.email, 
          name: payload.full_name,
          legacy_user_id: payload.user_id 
        };
      } catch (e) {
        // Fallback or let Firebase verify try
        isLegacy = false;
      }
    }

    if (!isLegacy) {
      decodedToken = await adminAuthInstance.verifyIdToken(token);
    }

    req.firebaseUser = decodedToken;

    // Check if the user exists in our SQL database
    let dbUser = null;

    if (isLegacy && decodedToken.legacy_user_id) {
      const results = await db.select().from(users).where(eq(users.id, Number(decodedToken.legacy_user_id)));
      if (results && results.length > 0) {
        dbUser = results[0];
      }
    }

    if (!dbUser && decodedToken.uid) {
      const results = await db.select().from(users).where(eq(users.uid, decodedToken.uid));
      if (results && results.length > 0) {
        dbUser = results[0];
      }
    }

    // If not found, check by Email (to link pre-existing spreadsheet/seed users)
    if (!dbUser && decodedToken.email) {
      const results = await db.select().from(users).where(eq(users.email, decodedToken.email.toLowerCase().trim()));
      if (results && results.length > 0) {
        dbUser = results[0];
        if (decodedToken.uid) {
          // Associate the Firebase UID with the database user record
          await db.update(users).set({ uid: decodedToken.uid }).where(eq(users.id, dbUser.id));
          dbUser.uid = decodedToken.uid;
        }
      }
    }

    // If user still doesn't exist (e.g. brand new user joining via Google sign-in), create a new record
    if (!dbUser && decodedToken.email) {
      const insertResult = await db.insert(users).values({
        uid: decodedToken.uid,
        email: decodedToken.email.toLowerCase().trim(),
        fullName: decodedToken.name || decodedToken.email.split('@')[0],
        role: 'user',
        hourlyRatePln: 28.10,
        taxPercent: 12.0
      }).returning();
      dbUser = insertResult[0];
    }

    if (!dbUser) {
      return res.status(401).json({ error: 'User could not be initialized in system' });
    }

    // Attach to req
    req.user = dbUser;
    next();
  } catch (error) {
    console.error('Error verifying ID token:', error);
    return res.status(401).json({ error: 'Auth token expired or invalid' });
  }
};
